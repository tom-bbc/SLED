import json
import random
import pickle

def sample_jsonl(input_file, output_file, sample_size):
    # 读取所有行并转换为JSON
    with open(input_file, 'r') as file:
        lines = [json.loads(line) for line in file]

    # 随机选择sample_size数量的JSON对象
    sampled_lines = random.sample(lines, sample_size)

    # 将抽样结果写入新文件，再次转换为字符串
    with open(output_file, 'w') as file:
        for line in sampled_lines:
            file.write(json.dumps(line) + '\n')

random.seed(42)
# 使用示例
sample_jsonl('gsm8k_test.jsonl', 'sampled_gsm8k_test.jsonl', 200)



wrong_list_file_name = "sampled_llama3_wrong_list_200ver.pkl"

with open(wrong_list_file_name, "rb") as file:
    wrong_list = pickle.load(file)


leis=[4, 8, 11, 12, 16, 25, 26, 29, 31, 34, 36, 42, 43, 48, 50, 52, 57, 63, 67, 70, 72, 76, 77, 80, 84, 85, 92, 93, 95, 97, 99, 106]